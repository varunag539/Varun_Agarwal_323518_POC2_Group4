package TESTNG_TESTS;

import org.apache.log4j.Logger;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import BASE_CLASSES.Authentication_Page;
import BASE_CLASSES.My_Account;
import UTILITIES.Excel;


public class NewTest2 extends NewTest{

My_Account ac;
SoftAssert sa;
Authentication_Page ap;
Excel re;
String [][] logintestdata;
int c=0;


@BeforeClass
public void bc()
{
re = new Excel();
logintestdata = re.readExcel();
}



@Test(dataProvider = "logindataprovider", priority=3)
 public void logInTest(String emailId, String pwd, String er)
 {
 ap = new Authentication_Page(dr);
 String str1 = ap.signin(emailId, pwd);
 sa = new SoftAssert();
 sa.assertEquals(str1, "Login - My Store");
 log=Logger.getLogger("devpinoyLogger");
 log.info("\n==========================================================================\n"
 	+ "-------------------------------Login Page Title Test--------------------------------\n"
 	+ "============================================================================\n");
   log.info("Expected Value : Login - My Store");
 	log.info(" Actual Value : "+str1);
 	log.info(" Test Result: Passed");
 ac = new My_Account(dr);
 accountTest(c);
 verifyName(er);
 ap.Signout();
 c++;
 

 }
 

 
 @DataProvider(name="logindataprovider")
 public String[][] testData(){

 return logintestdata;
 
 }
 
// public void accountTest()
// {
// String str2 = ac.gettitle();
// sa = new SoftAssert();
// sa.assertEquals(str2, "My account - My Store");
// log=Logger.getLogger("devpinoyLogger");
// log.info("\n===================================================================================\n"
// 	+ "-----------------------------------Account Test----------------------------------\n"
// 	+ "==================================================================================\n");
//    log.info("Expected Value : My account - My Store");
// 	log.info(" Actual Value : "+str2);
// 	log.info(" Test Result: Passed");
// 
// }
 
 
 
 public void accountTest(int f)
 {
	  String str2 = ac.gettitle();
	  sa = new SoftAssert();
	  String text = null;
	  if(f==0)
		  text = "My account - My Store";
	  else 
		  text = "Login - My Store";
	  sa.assertEquals(str2,text);
	  log=Logger.getLogger("devpinoyLogger");
	  log.info("\n===================================================================================\n"
		  		+ "-----------------------------------Account Test----------------------------------\n"
		  		+ "==================================================================================\n");
	  log.info("Expected Value : "+text);
 		log.info(" Actual Value : "+str2);
 		log.info(" Test Result: Passed");
		  
 }

 public void verifyName(String er)
 {
 String str2 = ac.Get_accountName();
 sa = new SoftAssert();
 sa.assertEquals(str2,er);
 log=Logger.getLogger("devpinoyLogger");
 log.info("\n===============================================================================\n"
 	+ "-------------------------------Profile Name Test--------------------------------\n"
 	+ "==============================================================================\n");
 log.info("Expected Value : "+er);
 	log.info(" Actual Value : "+str2);
 	log.info(" Test Result: Passed");
 
 }
 
}
