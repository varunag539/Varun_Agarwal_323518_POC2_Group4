package TESTNG_TESTS;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import BASE_CLASSES.Home_Page;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class NewTest {
	WebDriver dr;
	Home_Page homepage;
	Logger log;
	SoftAssert sa;

//	@BeforeClass
//	public void launchBrowser() {
//		homepage = new Home_Page(dr);
//		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
//		dr = new ChromeDriver();
//		dr.get("http://automationpractice.com/index.php");
//		// homepage.launchbrowser();
//
//	}

	@Test(priority = 1)
	public void test_homepage() {
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		dr = new ChromeDriver();
		homepage = new Home_Page(dr);
		homepage.launchbrowser();
		String ac_value = homepage.gettitle();

		System.out.println("Title: " + ac_value);
		sa = new SoftAssert();
		sa.assertEquals(ac_value, "My Store");
		log = Logger.getLogger("devpinoyLogger");
		log.info("\n========================================================================================\n"
				+ "===================================TC_Id: test_homepage================================== \n"
				+ "==========================================================================================\n"
				+ "test_homepage Expected Result : My Store \n" + "test_homepage Actual Result : " + ac_value + "\n"
				+ "test_homepage TEST RESULT : PASS");

	}

	@Test(priority = 2)
	public void SignInverificationtest() {
		homepage = new Home_Page(dr);
		String ac_value1 = homepage.getLoginTitle();
		System.out.println("Text: " + ac_value1);
		sa = new SoftAssert();
		sa.assertEquals(ac_value1, "Sign in");
		log = Logger.getLogger("devpinoyLogger");
		log.info("\n========================================================================================\n"
				+ "=======================TC_Id:SignInverificationtest====================================== \n"
				+ "==========================================================================================\n"
				+ "SignInverificationtest Expected Result : Sign in \n" + "test_homepage Actual Result : " + ac_value1 + "\n"
				+ "SignInverificationtest TEST RESULT : PASS");

	}

}
