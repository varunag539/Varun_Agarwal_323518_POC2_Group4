package UTILITIES;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

//POC_4_R2							
//Create a POM Framework using page factory & TestNG, automate test cases & perform the following:							
//Login 							
//http://automationpractice.com/index.php							
//1) For POM, create the classes for the following webpages : 							
//2) Class-1 : Home Page : Verify title & the text - "Sign In" in this class. Develop other methods in this class needed for login							
//3) Class-2 : Authentication Page : Verify title in this page. Develop other methods in this class needed for login							
//4) Class-3 : My account : Verify title in this page. Verfiy full name (first name & last name) on top right corner.
//This expected result of full name needs to be read from excel file.							
//5) Create 2 TestNG Class : Distribute the test methods for the verification in both the testng classes.							
//6) Use the  required annotations & use testng.xml file to execute the classes as a test suite.							
//7) Test data & expected result for primary feature to be read from external excel file with atleast two sets of data.							
//8) Use @Dataprovider for primary feature.							
//9) Review the testng html report file for correctness & export the same. 							
//10) Call the read_excel method using the @BeforeClass annotation.							
//11) Use priority to sequence the execution.							
//12) Use log4j & create the log file as per the given format.							
//13) Use Explicit wait & wait for the expected msg							
//Test run should go smoothly & test report to be generated.

public class Excel {


	public String[][] readExcel() {

		String[][] str = new String[2][3];

		try {
			File f = new File("email.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			for (int i = 0; i < 2; i++) {
				XSSFRow r = sh.getRow(i + 1);

				XSSFCell c = r.getCell(0);

				str[i][0] = c.getStringCellValue();
				str[i][1] = r.getCell(1).getStringCellValue();
				str[i][2] = r.getCell(2).getStringCellValue();
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return str;

	}

}
