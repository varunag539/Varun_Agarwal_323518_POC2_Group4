package BASE_CLASSES;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class My_Account {

	WebDriver dr;

	public My_Account(WebDriver dr) {

		this.dr = dr;
		PageFactory.initElements(dr, this);

	}

	public String gettitle() {

		return dr.getTitle();
	}

	@FindBy(xpath = "//*[@class = 'account']")
	WebElement AccountName;
	@FindBy(xpath = "//*[@id=\"center_column\"]/div[1]/ol/li")
	WebElement Error;

	public String Get_accountName() {

		try {

			boolean b = Error.isDisplayed();
			if (b)
				return Error.getText();

		} catch (NoSuchElementException e)

		{
			return AccountName.getText();
		}
		return AccountName.getText();
	}

	
}
