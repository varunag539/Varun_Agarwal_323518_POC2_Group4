package BASE_CLASSES;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Home_Page {

	WebDriver dr;

	public Home_Page(WebDriver dr) {

		this.dr = dr;
		PageFactory.initElements(dr, this);

	}

	public void launchbrowser() {

		dr.get("http://automationpractice.com/index.php");
	}

	public String gettitle() {

		return dr.getTitle();
	}

	@FindBy(xpath = "//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a")
	WebElement SignIn;

	public String getLoginTitle() {
		return SignIn.getText();
	}

}
