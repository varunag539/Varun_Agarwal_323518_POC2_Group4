package BASE_CLASSES;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Authentication_Page {

	WebDriver dr;

	public Authentication_Page(WebDriver dr) {

		this.dr = dr;
		PageFactory.initElements(dr, this);

	}

	@FindBy(xpath = "//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a")
	WebElement SignIn;
	@FindBy(xpath = "//*[@id=\"email\"]")
	WebElement Email;
	@FindBy(xpath = "//*[@id=\"passwd\"]")
	WebElement Password;
	@FindBy(xpath = "//*[@id=\"SubmitLogin\"]/span")
	WebElement clickSignin;

	public String signin(String s1, String s2) {

		SignIn.click();
		String str = dr.getTitle();
		Email.sendKeys(s1);
		Password.sendKeys(s2);
		clickSignin.click();
		return str;
	}
	
	
	@FindBy(xpath = "//*[@id=\"header\"]/div[2]/div/div/nav/div[2]/a")
	WebElement SignOut;
	
	public void Signout() {
		
		try
		{
			if(SignOut.isDisplayed())
				SignOut.click();
				
		}
		
		catch(NoSuchElementException n) {
			
			
		}
	}
	

}
